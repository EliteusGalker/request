import os
import shutil
from datetime import datetime, timedelta
import win32com.client as win32
import time
import pythoncom

from translate import Translator
import openpyxl
import sys



def pisz3():
    def get_script_directory():
        if getattr(sys, 'frozen', False):
            return os.path.dirname(os.path.abspath(sys.executable))
        else:
            return os.path.dirname(os.path.abspath(__file__))


    # Get today's date
    today = datetime.now().date()

    # Calculate the date after 1 day and 22 days
    future_date_1 = today + timedelta(days=1)
    future_date_22 = today + timedelta(days=22)

    # Format the dates as strings
    date_format = '%Y_%m_%d'
    new_name_uz = today.strftime(date_format) + '_UZ.docm'
    new_name_og = future_date_1.strftime(date_format) + '_OG.docm'

    new_name_rb = future_date_1.strftime(date_format) + '_RB.docm'
    new_name_zgl = 'ZGL.docm'
    new_name_zgl_ang = 'ZGL_ANG.docm'



    # Get the directory of the script
    script_directory = get_script_directory()
    print(script_directory)


    # Open Excel and run the VBA macro
    excel_path = os.path.join(script_directory, 'Dane.xlsm')
    print(excel_path)


    
    
    # Create a new instance of Excel using comtypes
    excel_app = win32.Dispatch("Excel.Application", pythoncom.CoInitialize())
    excel_app.Visible = False  # Set to True if you want Excel to be visible

    # Open the workbook
    workbook = excel_app.Workbooks.Open(excel_path)

    # Run the VBA macro
    macro_name = "SaveCellValueAndF2AsTxt"  # Replace with your macro name
    excel_app.Run(macro_name)
    time.sleep(5) # poczekać na PQ !!

    # Save and close the workbook
    workbook.Save()
    workbook.Close()
    excel_app.Quit()


    # Read content from miejsce.txt
    miejsce_file = os.path.join(script_directory, 'miejsce.txt')

    with open(miejsce_file, 'r', encoding='utf-16') as file:
        miejsce_content = file.read().strip()


    # Read content from uchwaly.txt
    uchwaly_file = os.path.join(script_directory, 'uchwaly.txt')
    with open(uchwaly_file, 'r', encoding='utf-16') as file:
        uchwaly_content = file.read().strip()

    CzyCert_file = os.path.join(script_directory, 'CzyCert.txt')
    with open(CzyCert_file, 'r', encoding='utf-16') as file:
        CzyCert_content = file.read().strip()

    KiedyZgl_file = os.path.join(script_directory, 'KiedyZgl.txt')
    with open(KiedyZgl_file, 'r', encoding='utf-16') as file:
        KiedyZgl_content = file.read().strip()

    podstawaZwolania_file = os.path.join(script_directory, 'podstawaZwolania.txt')
    with open(podstawaZwolania_file, 'r', encoding='utf-16') as file:
        podstawaZwolania_content = file.read().strip()


    print(miejsce_content)
    print(uchwaly_content)

    print(CzyCert_content)
    print(KiedyZgl_content)
    print(podstawaZwolania_content)

    # Initialize the Google Translator
    translator = Translator(to_lang='en', from_lang='pl')

    # Translate the content from Polish to English
    translated_miejsce_content = translator.translate(miejsce_content)
    translated_uchwaly_content = translator.translate(uchwaly_content)
    translated_CzyCert_content = translator.translate(CzyCert_content)
    translated_KiedyZgl_content = translator.translate(KiedyZgl_content)
    translated_podstawaZwolania_content = translator.translate(podstawaZwolania_content)

    # Open the existing Excel workbook
    excel_file_path = os.path.join(script_directory, 'tlumaczenie.xlsx')
    wb = openpyxl.load_workbook(excel_file_path)
    sheet = wb.active
    print(translated_miejsce_content)
    print(translated_uchwaly_content)

    print(translated_CzyCert_content)
    print(translated_KiedyZgl_content)

    print(translated_podstawaZwolania_content)


    # Write the translated content to cells
    sheet['A1'] = translated_miejsce_content
    sheet['B1'] = translated_uchwaly_content
    sheet['C1'] = translated_CzyCert_content
    sheet['D1'] = translated_KiedyZgl_content
    sheet['E1'] = translated_podstawaZwolania_content

    # Save the changes to the Excel workbook
    wb.save(excel_file_path)
    wb.close()

    print("Translated content written to tlumaczenie.xlsx.")




    # Create the folder
    folder_name = future_date_22.strftime(date_format)
    
    parent_folder = "ZgromadzenieFormalne"
    folder_path = os.path.join(parent_folder, folder_name)

    try:
        if os.path.exists(folder_path):
        # Remove the folder and its contents if it exists
            shutil.rmtree(folder_path)
            print(f"Folder '{folder_name}' and its contents deleted.")
        
        os.mkdir(folder_path)
        print(f"Folder '{folder_name}' created successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")
        
    
    


    # List of files to copy and rename
    files_to_copy_and_rename = {
        "UZ.docm": new_name_uz,
        "OG.docm": new_name_og,
        
        "RB.docm": new_name_rb,
        "ZGL.docm": new_name_zgl,
        "ZGL_ANG.docm": new_name_zgl_ang
    }


    # Read content from NazwaFunduszu.txt
    nazwa_funduszu_file = os.path.join(script_directory, 'NazwaFunduszu.txt')
    with open(nazwa_funduszu_file, 'r', encoding='utf-16') as file:
        nazwa_funduszu_content = file.read().strip()
     
    copied_files = []

    # Copy and rename files to the newly created folder, appending content to filenames
    for source_filename, destination_filename in files_to_copy_and_rename.items():
        source_file = os.path.join(script_directory, source_filename)
        destination_file = os.path.join("ZgromadzenieFormalne", folder_name, destination_filename + '_' + nazwa_funduszu_content + '.docm')
        
        try:
            shutil.copy2(source_file, destination_file)
            print(f"File '{source_filename}' copied and renamed to '{destination_filename}' successfully.")
        except FileNotFoundError:
            print(f"File '{source_filename}' not found.")
        except Exception as e:
            print(f"An error occurred while copying '{source_filename}': {e}")


    word = win32.gencache.EnsureDispatch('Word.Application')
    word.Visible = False

    for destination_filename in files_to_copy_and_rename.values():
        file_path = os.path.join("ZgromadzenieFormalne", script_directory, folder_name, destination_filename + '_' + nazwa_funduszu_content + '.docm')
        print(file_path)
        document = word.Documents.Open(file_path)
        word.Run('RefreshAndSaveAsDocmAndPdf')
        document.Close()
        
    word.Quit()


    for destination_filename in files_to_copy_and_rename.values():
        file_path = os.path.join("ZgromadzenieFormalne", script_directory, folder_name, destination_filename + '_' + nazwa_funduszu_content + '.docm')
        try:
            os.remove(file_path)
            print(f"File '{file_path}' deleted successfully.")
        except Exception as e:
                print(f"An error occurred while deleting '{file_path}': {e}")


if __name__ == '__main__':
    pisz3()
